pymupdf4llm_git_branch = 'main'
pymupdf4llm_git_comment = 'setup.py: add _build.py file to wheel/install containing git info.'
pymupdf4llm_git_diff = ''
pymupdf4llm_git_diff_n = 0
pymupdf4llm_git_sha = '288fe55282427a01df891cf5193ca65a0879735f'
